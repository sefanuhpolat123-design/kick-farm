package ai.venice.kickfarm

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.delay

enum class VpnState { CONNECTED, COOLDOWN, FAILED, NO_APP }

object VpnController {
    private const val PKG = "ch.protonvpn.android"
    private val CD = Regex("\\b\\d{1,2}:\\d{2}\\b")

    private fun launch(c: Context): Boolean {
        val i = c.packageManager.getLaunchIntentForPackage(PKG) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        return true
    }

    suspend fun connectRandom(c: Context, log: (String) -> Unit): VpnState {
        if (!launch(c)) { log("ProtonVPN kurulu degil"); return VpnState.NO_APP }
        delay(3500)
        val a = A11yService.instance ?: return VpnState.FAILED
        val screen = a.dumpText()

        if (CD.containsMatchIn(screen)) {
            log("Cooldown: " + (CD.find(screen)?.value ?: "?"))
            return VpnState.COOLDOWN
        }
        if (a.clickNode("Sunucu degistir", "Change server", "Change Server")) {
            log("Sunucu degistiriliyor")
            delay(7000)
        } else if (a.clickNode("Baglan", "Connect", "Quick Connect")) {
            log("VPN baglaniyor")
            delay(10000)
        } else {
            log("VPN dugmesi bulunamadi")
            return VpnState.FAILED
        }

        val after = a.dumpText()
        if (CD.containsMatchIn(after)) { log("Cooldown olustu, VPN'siz devam"); return VpnState.COOLDOWN }
        if (after.contains("Connected", true)) return VpnState.CONNECTED
        return VpnState.FAILED
    }

    suspend fun disconnect(c: Context) {
        val a = A11yService.instance ?: return
        launch(c)
        delay(2500)
        a.clickNode("Baglantiyi kes", "Disconnect")
        delay(2500)
    }
}
