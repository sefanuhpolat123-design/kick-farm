package ai.venice.kickfarm

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class A11yService : AccessibilityService() {
    companion object { @Volatile var instance: A11yService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    fun findNode(vararg labels: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            val t = (n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")
            if (labels.any { t.contains(it, true) }) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    fun clickNode(vararg labels: String): Boolean {
        var cur: AccessibilityNodeInfo? = findNode(*labels) ?: return false
        while (cur != null) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
        }
        return false
    }

    fun dumpText(): String {
        val sb = StringBuilder()
        val root = rootInActiveWindow ?: return ""
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            n.text?.let { sb.append(it).append('\n') }
            n.contentDescription?.let { sb.append(it).append('\n') }
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return sb.toString()
    }
}
