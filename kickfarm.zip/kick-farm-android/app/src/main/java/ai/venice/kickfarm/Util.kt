package ai.venice.kickfarm

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Logx {
    var sink: ((String) -> Unit)? = null
    private var dir: File? = null
    fun init(c: Context) { dir = c.getExternalFilesDir(null)?.apply { mkdirs() } }
    fun i(m: String) = w(m)
    fun w(m: String) {
        val line = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()) + "  " + m
        Log.i("KickFarm", line)
        runCatching { dir?.let { File(it, "log.txt").appendText(line + "\n") } }
        sink?.invoke(line)
    }
}

object Db {
    private var dir: File? = null
    fun init(c: Context) { dir = c.getExternalFilesDir(null)?.apply { mkdirs() } }
    fun save(idx: Int, email: String, user: String, status: String) =
        append("accounts.txt", idx.toString() + "\t" + email + "\t" + user + "\t" + Config.password + "\t" + status + "\t" + System.currentTimeMillis())
    fun append(name: String, line: String) { runCatching { dir?.let { File(it, name).appendText(line + "\n") } } }
    fun nextIndex(): Int = runCatching {
        dir?.let { File(it, "accounts.txt") }?.readLines()?.lastOrNull()?.split("\t")?.first()?.toInt()
    }.getOrNull()?.plus(1) ?: 1
}
