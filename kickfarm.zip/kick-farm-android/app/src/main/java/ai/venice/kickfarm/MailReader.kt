package ai.venice.kickfarm

import kotlinx.coroutines.delay
import java.util.Properties
import javax.mail.Flags
import javax.mail.Folder
import javax.mail.Message
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.Session
import javax.mail.search.AndTerm
import javax.mail.search.FlagTerm
import javax.mail.search.RecipientStringTerm

data class VerifyToken(val kind: String, val value: String)

object MailReader {
    private val CODE = Regex("(?i)(?:kod|code)[^0-9]{0,40}(\\d{6})")
    private val LINK = Regex("https://kick\\.com/[^\\s\"'<>]*(?:verify|confirm)[^\\s\"'<>]*")

    suspend fun waitFor(alias: String, timeoutMs: Long = 240_000): VerifyToken? {
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            runCatching { readOnce(alias) }.getOrNull()?.let { return it }
            delay(6000)
        }
        return null
    }

    private fun readOnce(alias: String): VerifyToken? {
        val p = Properties()
        p.put("mail.store.protocol", "imaps")
        p.put("mail.imaps.host", "imap.gmail.com")
        p.put("mail.imaps.port", "993")
        p.put("mail.imaps.ssl.enable", "true")
        val store = Session.getInstance(p).getStore("imaps")
        store.connect("imap.gmail.com", Config.baseEmail, Config.appPassword)
        try {
            val box = store.getFolder("INBOX")
            box.open(Folder.READ_WRITE)
            val term = AndTerm(FlagTerm(Flags(Flags.Flag.SEEN), false),
                RecipientStringTerm(Message.RecipientType.TO, alias))
            for (m in box.search(term).reversed()) {
                val body = bodyOf(m)
                if (!body.contains("kick", true)) continue
                m.setFlag(Flags.Flag.SEEN, true)
                CODE.find(body)?.let { c -> return VerifyToken("code", c.groupValues[1]) }
                LINK.find(body)?.let { l -> return VerifyToken("link", l.value.replace("&amp;", "&")) }
            }
        } finally {
            runCatching { store.close() }
        }
        return null
    }

    private fun bodyOf(m: Message): String {
        val sb = StringBuilder()
        collect(sb, m)
        return sb.toString()
    }

    private fun collect(sb: StringBuilder, part: Part) {
        when {
            part.isMimeType("text/plain") || part.isMimeType("text/html") -> sb.append(part.content?.toString() ?: "")
            part.isMimeType("multipart/*") -> {
                val mp = part.content as Multipart
                for (i in 0 until mp.count) collect(sb, mp.getBodyPart(i))
            }
        }
    }
}
