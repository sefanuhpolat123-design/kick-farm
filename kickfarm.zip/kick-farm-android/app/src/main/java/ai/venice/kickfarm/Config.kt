package ai.venice.kickfarm

import android.content.Context
import android.content.SharedPreferences

object Config {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("cfg", 0) }

    var baseEmail: String
        get() = sp.getString("email", "sefanuhpolat1@gmail.com")!!
        set(v) { sp.edit().putString("email", v).apply() }
    var appPassword: String
        get() = sp.getString("apppass", "")!!
        set(v) { sp.edit().putString("apppass", v).apply() }
    var tgToken: String
        get() = sp.getString("tgtoken", "")!!
        set(v) { sp.edit().putString("tgtoken", v).apply() }
    var tgChat: String
        get() = sp.getString("tgchat", "")!!
        set(v) { sp.edit().putString("tgchat", v).apply() }
    var password: String
        get() = sp.getString("pass", "Sefa321@")!!
        set(v) { sp.edit().putString("pass", v).apply() }

    val intervalMs get() = 300_000L
    val jitterMs get() = 45_000L
    val bareIfCooldown get() = sp.getBoolean("bare", true)
}
