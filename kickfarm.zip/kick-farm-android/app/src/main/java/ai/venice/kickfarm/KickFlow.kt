package ai.venice.kickfarm

import android.webkit.WebView
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object KickFlow {
    private fun esc(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"

    private suspend fun WebView.js(code: String): String = suspendCancellableCoroutine { c ->
        post {
            evaluateJavascript("(function(){try{return JSON.stringify(" + code + ")}catch(e){return '\"ERR\"'}})()") {
                c.resume(it ?: "null")
            }
        }
    }

    private suspend fun WebView.waitFor(cond: String, ms: Long = 25000): Boolean {
        val end = System.currentTimeMillis() + ms
        while (System.currentTimeMillis() < end) {
            if (js(cond).contains("true")) return true
            delay(700)
        }
        return false
    }

    suspend fun signUp(w: WebView, email: String, user: String, pass: String, dob: String): Boolean {
        w.loadUrl("https://kick.com/")
        delay(4500)
        w.js("(()=>{const b=[...document.querySelectorAll('button,a')].find(e=>/sign up|kayit ol/i.test(e.innerText));if(b){b.click();return true}return false})()")
        if (!w.waitFor("(()=>!!document.querySelector(\"input[type=email]\"))()")) return false
        val setter = "const set=(el,v)=>{const s=Object.getOwnPropertyDescriptor(el.constructor.prototype,'value').set;s.call(el,v);el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}))};"
        w.js("(()=>{" + setter + "const q=s=>document.querySelector(s);" +
            "set(q(\"input[type=email]\")," + esc(email) + ");" +
            "const u=q(\"input[name=username],input[placeholder*=sername]\"); if(u) set(u," + esc(user) + ");" +
            "set(q(\"input[type=password]\")," + esc(pass) + ");" +
            "const d=q(\"input[type=date]\"); if(d) set(d," + esc(dob) + ");" +
            "return true})()")
        delay(900)
        w.js("(()=>{const b=[...document.querySelectorAll('button')].filter(e=>/sign up|kayit/i.test(e.innerText)).pop();if(b){b.click();return true}return false})()")
        return true
    }

    suspend fun hasTurnstile(w: WebView): Boolean =
        w.js("(()=>!!document.querySelector('iframe[src*=challenges],#challenge-stage'))()").contains("true")

    suspend fun applyCode(w: WebView, code: String): Boolean {
        val ok = w.js("(()=>{const b=[...document.querySelectorAll(\"input[inputmode=numeric],input[name*=code],input[placeholder*=code]\")];" +
            "if(!b.length) return false;" +
            "b.forEach((el,i)=>{const s=Object.getOwnPropertyDescriptor(el.constructor.prototype,'value').set;s.call(el," + esc(code) + "[i]||'');el.dispatchEvent(new Event('input',{bubbles:true}))});" +
            "const btn=[...document.querySelectorAll('button')].find(e=>/verify|dogrula|confirm|submit/i.test(e.innerText)); if(btn) btn.click();" +
            "return true})()").contains("true")
        delay(4000)
        return ok
    }

    suspend fun openFreeCase(w: WebView): String {
        w.loadUrl("https://kick.com/")
        delay(5500)
        w.js("(()=>{const b=[...document.querySelectorAll('button,a')].find(e=>/skip|later|atla/i.test(e.innerText));if(b)b.click();return true})()")
        delay(1500)
        val clicked = w.js("(()=>{const c=[...document.querySelectorAll('button,[role=button]')]" +
            ".find(e=>/reward|case|kutu|sunset/i.test((e.getAttribute('aria-label')||'')+e.innerText+(e.dataset.testid||'')));" +
            "if(c){c.click();return true}return false})()").contains("true")
        if (!clicked) return "nobox"
        delay(3000)
        w.js("(()=>{const b=[...document.querySelectorAll('button')].find(e=>/^open|kutuyu ac|^ac$/i.test(e.innerText.trim()));if(b)b.click();return true})()")
        delay(9000)
        val t = w.js("document.body.innerText.toLowerCase()")
        val score = listOf("gta vi", "gta 6", "you won", "winner", "congratulations", "ultimate edition", "select platform", "xbox", "ps5").count { t.contains(it) }
        return if (score >= 2) "WIN" else "loss:" + score
    }
}
