package ai.venice.kickfarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Notifier {
    fun win(c: Context, email: String, user: String, pass: String) {
        val msg = "GTA VI CIKTI\n" + email + "\n" + user + " / " + pass
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("win", "Kazanim", NotificationManager.IMPORTANCE_HIGH)
            .apply { sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) })
        nm.notify(1, NotificationCompat.Builder(c, "win")
            .setSmallIcon(android.R.drawable.star_big_on)
            .setContentTitle("GTA VI KUTUDAN CIKTI")
            .setContentText(user + " / " + pass)
            .setStyle(NotificationCompat.BigTextStyle().bigText(msg))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .build())
        Db.append("WINNERS.txt", msg.replace("\n", " | "))
        if (Config.tgToken.isNotBlank() && Config.tgChat.isNotBlank()) GlobalScope.launch {
            runCatching {
                val conn = URL("https://api.telegram.org/bot" + Config.tgToken + "/sendMessage").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.outputStream.write(("chat_id=" + Config.tgChat + "&text=" + URLEncoder.encode(msg, "UTF-8")).toByteArray())
                conn.responseCode
            }
        }
    }
}
