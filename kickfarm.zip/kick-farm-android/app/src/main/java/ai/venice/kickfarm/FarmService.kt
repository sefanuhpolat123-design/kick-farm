package ai.venice.kickfarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class FarmService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("run", "Calisiyor", NotificationManager.IMPORTANCE_LOW))
        startForeground(2, NotificationCompat.Builder(this, "run")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("KickFarm calisiyor")
            .setOngoing(true)
            .build())
        return START_STICKY
    }
}
