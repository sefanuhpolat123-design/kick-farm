package ai.venice.kickfarm

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView
    private var web: WebView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Config.init(this)
        Logx.init(this)
        Db.init(this)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(24, 48, 24, 24)

        root.addView(field("Gmail adresi", Config.baseEmail) { Config.baseEmail = it })
        root.addView(field("Gmail uygulama sifresi", Config.appPassword) { Config.appPassword = it })
        root.addView(field("Telegram bot token (opsiyonel)", Config.tgToken) { Config.tgToken = it })
        root.addView(field("Telegram chat id", Config.tgChat) { Config.tgChat = it })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(Button(this).apply { text = "BASLAT"; setOnClickListener { go() } })
        row.addView(Button(this).apply { text = "DUR"; setOnClickListener { FarmEngine.stop() } })
        row.addView(Button(this).apply { text = "IZINLER"; setOnClickListener { perms() } })
        root.addView(row)

        scroll = ScrollView(this)
        val tv = TextView(this)
        tv.textSize = 10f
        logView = tv
        scroll.addView(tv)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 280))

        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.databaseEnabled = true
        w.settings.userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        WebView.setWebContentsDebuggingEnabled(true)
        web = w
        root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)

        Logx.sink = { l ->
            runOnUiThread {
                logView.append(l + "\n")
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
    }

    private fun field(hint: String, value: String, save: (String) -> Unit): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.textSize = 12f
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = save(s.toString())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        return e
    }

    private fun go() {
        perms()
        if (Config.appPassword.isBlank()) { Logx.w("Gmail uygulama sifresi bos!"); return }
        startForegroundService(Intent(this, FarmService::class.java))
        web?.let { FarmEngine.start(this, it) }
    }

    private fun perms() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        if (!Settings.canDrawOverlays(this))
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        val a = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        if (!a.contains(packageName)) {
            Toast.makeText(this, "Erisilebilirlik servisini ac", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        runCatching {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName)))
        }
    }
}
