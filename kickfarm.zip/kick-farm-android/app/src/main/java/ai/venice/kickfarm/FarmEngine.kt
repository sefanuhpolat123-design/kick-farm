package ai.venice.kickfarm

import android.content.Context
import android.webkit.WebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.random.Random

object FarmEngine {
    private var job: Job? = null
    private val ADJ = listOf("silent", "rapid", "cobalt", "lunar", "amber", "neon", "velvet", "crimson", "idle", "vivid")
    private val NOUN = listOf("falcon", "harbor", "ember", "orbit", "pixel", "cedar", "raven", "delta", "sonic", "cipher")
    val running get() = job?.isActive == true

    fun start(ctx: Context, wv: WebView) {
        if (running) return
        job = CoroutineScope(Dispatchers.Main + SupervisorJob()).launch {
            var idx = Db.nextIndex()
            while (isActive) {
                runCatching { cycle(ctx, wv, idx) }.onFailure { Logx.w("tur: " + it.message) }
                idx++
                val w = Config.intervalMs + Random.nextLong(-Config.jitterMs, Config.jitterMs)
                Logx.i((w / 1000).toString() + "s bekleme")
                delay(w)
            }
        }
    }

    fun stop() { job?.cancel(); job = null; Logx.w("DURDURULDU") }

    private suspend fun cycle(ctx: Context, wv: WebView, idx: Int) {
        val alias = Config.baseEmail.replace("@", "+" + idx + "@")
        val user = ADJ.random() + NOUN.random() + Random.nextInt(10, 9999)
        Logx.i("#" + idx + "  " + alias + "  " + user)

        when (VpnController.connectRandom(ctx) { Logx.i(it) }) {
            VpnState.COOLDOWN -> if (Config.bareIfCooldown) VpnController.disconnect(ctx)
            VpnState.NO_APP -> Logx.w("VPN yok, gercek IP")
            else -> {}
        }

        if (!KickFlow.signUp(wv, alias, user, Config.password, dob())) {
            Logx.w("form acilmadi")
            Db.save(idx, alias, user, "fail")
            return
        }
        delay(5000)
        if (KickFlow.hasTurnstile(wv)) { Logx.w("Turnstile, 20s mudahale"); delay(20000) }

        val tok = MailReader.waitFor(alias)
        if (tok == null) { Logx.w("kod/link gelmedi"); Db.save(idx, alias, user, "fail"); return }
        if (tok.kind == "link") wv.loadUrl(tok.value) else KickFlow.applyCode(wv, tok.value)
        delay(5000)

        when (val r = KickFlow.openFreeCase(wv)) {
            "nobox" -> { Logx.w("kutu yok"); Db.save(idx, alias, user, "fail") }
            "WIN" -> {
                Db.save(idx, alias, user, "WIN")
                Logx.w("*** GTA VI ***")
                Notifier.win(ctx, alias, user, Config.password)
                stop()
            }
            else -> { Db.save(idx, alias, user, "ok"); Logx.i("sonuc " + r) }
        }
    }

    private fun dob(): String {
        val y = Calendar.getInstance().get(Calendar.YEAR) - Random.nextInt(19, 43)
        return String.format("%04d-%02d-%02d", y, Random.nextInt(1, 13), Random.nextInt(1, 29))
    }
}
