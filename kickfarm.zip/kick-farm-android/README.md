# KickFarm (Android)

Kick'te otomatik hesap açıp ücretsiz Sunset Reward Case açan, GTA VI çıkarsa duran uygulama.

## Derleme
1. Bu ZIP'i bir GitHub repo'sunun **release** asset'i olarak yükle.
2. `.github/workflows/apk.yml` otomatik çalışır, `kickfarm-apk` artifact'ından APK'yı indir.

## Telefonda
1. APK kur, aç.
2. İzinler: bildirim, diğer uygulamaların üzerinde göster, erişilebilirlik servisi, pil muafiyeti.
3. Gmail adresi + Gmail uygulama şifresi gir (2FA açık olmalı).
4. ProtonVPN'e bir kez elle gir ve bağlan.
5. BASLAT. Ekran açık ve fişe takılı kalsın.

## Çıktılar
`/sdcard/Android/data/ai.venice.kickfarm/files/` → accounts.txt, WINNERS.txt, log.txt

## Notlar
- Kick arayüzü değişirse: KickFlow.kt
- ProtonVPN düğmeleri değişirse: VpnController.kt
