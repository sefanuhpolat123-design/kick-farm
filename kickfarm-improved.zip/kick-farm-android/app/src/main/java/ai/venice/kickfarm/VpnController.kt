package ai.venice.kickfarm

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.delay

enum class VpnState {
    CONNECTED,
    COOLDOWN,
    FAILED,
    NO_APP
}

object VpnController {
    private const val PACKAGE_NAME = "ch.protonvpn.android"
    private val COOLDOWN_PATTERN = Regex("""\b\d{1,2}:\d{2}\b""")

    private fun launch(context: Context): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(PACKAGE_NAME) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    suspend fun connectRandom(context: Context, log: (String) -> Unit): VpnState {
        if (!launch(context)) {
            log("ProtonVPN kurulu değil")
            return VpnState.NO_APP
        }

        delay(3500)
        val service = A11yService.instance ?: return VpnState.FAILED
        val screen = service.dumpText()

        if (COOLDOWN_PATTERN.containsMatchIn(screen)) {
            val remaining = COOLDOWN_PATTERN.find(screen)?.value ?: "?"
            log("Cooldown: $remaining")
            return VpnState.COOLDOWN
        }

        when {
            service.clickNode("Sunucu değiştir", "Change server", "Change Server") -> {
                log("Sunucu değiştiriliyor")
                delay(7000)
            }
            service.clickNode("Bağlan", "Connect", "Quick Connect") -> {
                log("VPN bağlanıyor")
                delay(10_000)
            }
            else -> {
                log("VPN düğmesi bulunamadı")
                return VpnState.FAILED
            }
        }

        val after = service.dumpText()
        if (COOLDOWN_PATTERN.containsMatchIn(after)) {
            log("Cooldown oluştu, VPN'siz devam")
            return VpnState.COOLDOWN
        }
        return if (after.contains("Connected", ignoreCase = true)) {
            VpnState.CONNECTED
        } else {
            VpnState.FAILED
        }
    }

    suspend fun disconnect(context: Context) {
        val service = A11yService.instance ?: return
        launch(context)
        delay(2500)
        service.clickNode("Bağlantıyı kes", "Disconnect")
        delay(2500)
    }
}
