package ai.venice.kickfarm

import android.content.Context
import android.webkit.WebView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Calendar
import kotlin.random.Random

object FarmEngine {
    private var job: Job? = null

    private val ADJECTIVES = listOf(
        "silent", "rapid", "cobalt", "lunar", "amber",
        "neon", "velvet", "crimson", "idle", "vivid"
    )
    private val NOUNS = listOf(
        "falcon", "harbor", "ember", "orbit", "pixel",
        "cedar", "raven", "delta", "sonic", "cipher"
    )

    val isRunning: Boolean
        get() = job?.isActive == true

    fun start(context: Context, webView: WebView) {
        if (isRunning) return

        job = CoroutineScope(Dispatchers.Main + SupervisorJob()).launch {
            var index = Db.nextIndex()
            while (isActive) {
                runCatching {
                    runCycle(context, webView, index)
                }.onFailure { error ->
                    Logx.w("tur hatası: ${error.message}")
                }
                index++
                val waitMs = Config.intervalMs + Random.nextLong(-Config.jitterMs, Config.jitterMs)
                Logx.i("${waitMs / 1000}s bekleme")
                delay(waitMs)
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
        Logx.w("DURDURULDU")
    }

    private suspend fun runCycle(context: Context, webView: WebView, index: Int) {
        val alias = Config.baseEmail.replace("@", "+$index@")
        val username = ADJECTIVES.random() + NOUNS.random() + Random.nextInt(10, 9999)
        Logx.i("#$index  $alias  $username")

        when (VpnController.connectRandom(context) { Logx.i(it) }) {
            VpnState.COOLDOWN -> {
                if (Config.continueWithoutVpnOnCooldown) {
                    VpnController.disconnect(context)
                }
            }
            VpnState.NO_APP -> Logx.w("VPN yok, gerçek IP kullanılıyor")
            else -> Unit
        }

        if (!KickFlow.signUp(webView, alias, username, Config.password, generateDateOfBirth())) {
            Logx.w("form açılamadı")
            Db.save(index, alias, username, "fail")
            return
        }

        delay(5000)

        if (KickFlow.hasTurnstile(webView)) {
            Logx.w("Turnstile algılandı, 20s müdahale bekleniyor")
            delay(20_000)
        }

        val token = MailReader.waitFor(alias)
        if (token == null) {
            Logx.w("kod/link gelmedi")
            Db.save(index, alias, username, "fail")
            return
        }

        if (token.kind == "link") {
            webView.loadUrl(token.value)
        } else {
            KickFlow.applyCode(webView, token.value)
        }
        delay(5000)

        when (val result = KickFlow.openFreeCase(webView)) {
            "nobox" -> {
                Logx.w("kutu yok")
                Db.save(index, alias, username, "fail")
            }
            "WIN" -> {
                Db.save(index, alias, username, "WIN")
                Logx.w("*** GTA VI ***")
                Notifier.win(context, alias, username, Config.password)
                stop()
            }
            else -> {
                Db.save(index, alias, username, "ok")
                Logx.i("sonuç: $result")
            }
        }
    }

    private fun generateDateOfBirth(): String {
        val year = Calendar.getInstance().get(Calendar.YEAR) - Random.nextInt(19, 43)
        val month = Random.nextInt(1, 13)
        val day = Random.nextInt(1, 29)
        return "%04d-%02d-%02d".format(year, month, day)
    }
}
