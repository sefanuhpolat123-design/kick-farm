package ai.venice.kickfarm

import kotlinx.coroutines.delay
import java.util.Properties
import javax.mail.Flags
import javax.mail.Folder
import javax.mail.Message
import javax.mail.Multipart
import javax.mail.Part
import javax.mail.Session
import javax.mail.search.AndTerm
import javax.mail.search.FlagTerm
import javax.mail.search.RecipientStringTerm

data class VerifyToken(
    val kind: String,
    val value: String
)

object MailReader {
    private val CODE_PATTERN = Regex("""(?i)(?:kod|code)[^0-9]{0,40}(\d{6})""")
    private val LINK_PATTERN = Regex("""https://kick\.com/[^\s"'<>]*(?:verify|confirm)[^\s"'<>]*""")

    suspend fun waitFor(alias: String, timeoutMs: Long = 240_000L): VerifyToken? {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            runCatching { readOnce(alias) }.getOrNull()?.let { return it }
            delay(6000)
        }
        return null
    }

    private fun readOnce(alias: String): VerifyToken? {
        val properties = Properties().apply {
            put("mail.store.protocol", "imaps")
            put("mail.imaps.host", "imap.gmail.com")
            put("mail.imaps.port", "993")
            put("mail.imaps.ssl.enable", "true")
        }

        val store = Session.getInstance(properties).getStore("imaps")
        store.connect("imap.gmail.com", Config.baseEmail, Config.appPassword)

        try {
            val inbox = store.getFolder("INBOX")
            inbox.open(Folder.READ_WRITE)

            val term = AndTerm(
                FlagTerm(Flags(Flags.Flag.SEEN), false),
                RecipientStringTerm(Message.RecipientType.TO, alias)
            )

            for (message in inbox.search(term).reversed()) {
                val body = extractBody(message)
                if (!body.contains("kick", ignoreCase = true)) continue

                message.setFlag(Flags.Flag.SEEN, true)

                CODE_PATTERN.find(body)?.let { match ->
                    return VerifyToken("code", match.groupValues[1])
                }
                LINK_PATTERN.find(body)?.let { match ->
                    return VerifyToken("link", match.value.replace("&amp;", "&"))
                }
            }
        } finally {
            runCatching { store.close() }
        }
        return null
    }

    private fun extractBody(message: Message): String {
        val builder = StringBuilder()
        collectText(builder, message)
        return builder.toString()
    }

    private fun collectText(builder: StringBuilder, part: Part) {
        when {
            part.isMimeType("text/plain") || part.isMimeType("text/html") -> {
                builder.append(part.content?.toString().orEmpty())
            }
            part.isMimeType("multipart/*") -> {
                val multipart = part.content as Multipart
                for (i in 0 until multipart.count) {
                    collectText(builder, multipart.getBodyPart(i))
                }
            }
        }
    }
}
