package ai.venice.kickfarm

import android.content.Context
import android.content.SharedPreferences

object Config {
    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    var baseEmail: String
        get() = prefs.getString(KEY_EMAIL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_EMAIL, value).apply()

    var appPassword: String
        get() = prefs.getString(KEY_APP_PASSWORD, "") ?: ""
        set(value) = prefs.edit().putString(KEY_APP_PASSWORD, value).apply()

    var telegramToken: String
        get() = prefs.getString(KEY_TG_TOKEN, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TG_TOKEN, value).apply()

    var telegramChatId: String
        get() = prefs.getString(KEY_TG_CHAT, "") ?: ""
        set(value) = prefs.edit().putString(KEY_TG_CHAT, value).apply()

    var password: String
        get() = prefs.getString(KEY_PASSWORD, DEFAULT_PASSWORD) ?: DEFAULT_PASSWORD
        set(value) = prefs.edit().putString(KEY_PASSWORD, value).apply()

    val intervalMs: Long
        get() = prefs.getLong(KEY_INTERVAL, DEFAULT_INTERVAL_MS)

    val jitterMs: Long
        get() = prefs.getLong(KEY_JITTER, DEFAULT_JITTER_MS)

    val continueWithoutVpnOnCooldown: Boolean
        get() = prefs.getBoolean(KEY_BARE_ON_COOLDOWN, true)

    private const val PREFS_NAME = "cfg"
    private const val KEY_EMAIL = "email"
    private const val KEY_APP_PASSWORD = "apppass"
    private const val KEY_TG_TOKEN = "tgtoken"
    private const val KEY_TG_CHAT = "tgchat"
    private const val KEY_PASSWORD = "pass"
    private const val KEY_INTERVAL = "interval"
    private const val KEY_JITTER = "jitter"
    private const val KEY_BARE_ON_COOLDOWN = "bare"

    private const val DEFAULT_PASSWORD = "KickFarm321@"
    private const val DEFAULT_INTERVAL_MS = 300_000L
    private const val DEFAULT_JITTER_MS = 45_000L
}
