package ai.venice.kickfarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Notifier {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun win(context: Context, email: String, username: String, password: String) {
        val message = "GTA VI ÇIKTI\n$email\n$username / $password"
        val manager = context.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(
            CHANNEL_ID,
            "Kazanim",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
        }
        manager.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.star_big_on)
            .setContentTitle("GTA VI KUTUDAN ÇIKTI")
            .setContentText("$username / $password")
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setOngoing(true)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
        Db.append("WINNERS.txt", message.replace("\n", " | "))

        if (Config.telegramToken.isNotBlank() && Config.telegramChatId.isNotBlank()) {
            scope.launch {
                runCatching {
                    val url = URL("https://api.telegram.org/bot${Config.telegramToken}/sendMessage")
                    val connection = url.openConnection() as HttpURLConnection
                    connection.requestMethod = "POST"
                    connection.doOutput = true
                    val body = "chat_id=${Config.telegramChatId}&text=${URLEncoder.encode(message, "UTF-8")}"
                    connection.outputStream.use { it.write(body.toByteArray()) }
                    connection.responseCode
                }
            }
        }
    }

    private const val CHANNEL_ID = "win"
    private const val NOTIFICATION_ID = 1
}
