package ai.venice.kickfarm

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Logx {
    private const val TAG = "KickFarm"
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    var sink: ((String) -> Unit)? = null
    private var logDir: File? = null

    fun init(context: Context) {
        logDir = context.getExternalFilesDir(null)?.apply { mkdirs() }
    }

    fun i(message: String) = write(message)
    fun w(message: String) = write(message)

    private fun write(message: String) {
        val line = "${timeFormat.format(Date())}  $message"
        Log.i(TAG, line)
        runCatching {
            logDir?.let { File(it, "log.txt").appendText("$line\n") }
        }
        sink?.invoke(line)
    }
}

object Db {
    private var dataDir: File? = null

    fun init(context: Context) {
        dataDir = context.getExternalFilesDir(null)?.apply { mkdirs() }
    }

    fun save(index: Int, email: String, username: String, status: String) {
        val line = listOf(
            index,
            email,
            username,
            Config.password,
            status,
            System.currentTimeMillis()
        ).joinToString("\t")
        append("accounts.txt", line)
    }

    fun append(filename: String, line: String) {
        runCatching {
            dataDir?.let { File(it, filename).appendText("$line\n") }
        }
    }

    fun nextIndex(): Int {
        return runCatching {
            dataDir
                ?.let { File(it, "accounts.txt") }
                ?.takeIf { it.exists() }
                ?.readLines()
                ?.lastOrNull()
                ?.split("\t")
                ?.firstOrNull()
                ?.toIntOrNull()
                ?.plus(1)
        }.getOrNull() ?: 1
    }
}
