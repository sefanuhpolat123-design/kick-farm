package ai.venice.kickfarm

import android.webkit.WebView
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object KickFlow {

    private fun escape(value: String): String =
        "'" + value.replace("\\", "\\\\").replace("'", "\\'") + "'"

    private suspend fun WebView.evaluate(code: String): String =
        suspendCancellableCoroutine { continuation ->
            post {
                evaluateJavascript(
                    "(function(){try{return JSON.stringify($code)}catch(e){return '\"ERR\"'}})()"
                ) { result ->
                    continuation.resume(result ?: "null")
                }
            }
        }

    private suspend fun WebView.waitFor(condition: String, timeoutMs: Long = 25_000L): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (evaluate(condition).contains("true")) return true
            delay(700)
        }
        return false
    }

    suspend fun signUp(
        webView: WebView,
        email: String,
        username: String,
        password: String,
        dateOfBirth: String
    ): Boolean {
        webView.loadUrl("https://kick.com/")
        delay(4500)

        webView.evaluate(
            """
            (() => {
                const button = [...document.querySelectorAll('button,a')]
                    .find(el => /sign up|kayit ol/i.test(el.innerText));
                if (button) { button.click(); return true; }
                return false;
            })()
            """.trimIndent()
        )

        if (!webView.waitFor("""(() => !!document.querySelector("input[type=email]"))()""")) {
            return false
        }

        val setter = """
            const set = (el, v) => {
                const descriptor = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value');
                descriptor.set.call(el, v);
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
            };
        """.trimIndent()

        webView.evaluate(
            """
            (() => {
                $setter
                const q = s => document.querySelector(s);
                set(q("input[type=email]"), ${escape(email)});
                const usernameInput = q("input[name=username],input[placeholder*=sername]");
                if (usernameInput) set(usernameInput, ${escape(username)});
                set(q("input[type=password]"), ${escape(password)});
                const dobInput = q("input[type=date]");
                if (dobInput) set(dobInput, ${escape(dateOfBirth)});
                return true;
            })()
            """.trimIndent()
        )

        delay(900)

        webView.evaluate(
            """
            (() => {
                const button = [...document.querySelectorAll('button')]
                    .filter(el => /sign up|kayit/i.test(el.innerText))
                    .pop();
                if (button) { button.click(); return true; }
                return false;
            })()
            """.trimIndent()
        )

        return true
    }

    suspend fun hasTurnstile(webView: WebView): Boolean =
        webView.evaluate(
            """(() => !!document.querySelector('iframe[src*=challenges],#challenge-stage'))()"""
        ).contains("true")

    suspend fun applyCode(webView: WebView, code: String): Boolean {
        val success = webView.evaluate(
            """
            (() => {
                const inputs = [...document.querySelectorAll(
                    "input[inputmode=numeric],input[name*=code],input[placeholder*=code]"
                )];
                if (!inputs.length) return false;
                inputs.forEach((el, i) => {
                    const descriptor = Object.getOwnPropertyDescriptor(el.constructor.prototype, 'value');
                    descriptor.set.call(el, ${escape(code)}[i] || '');
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                });
                const button = [...document.querySelectorAll('button')]
                    .find(el => /verify|dogrula|confirm|submit/i.test(el.innerText));
                if (button) button.click();
                return true;
            })()
            """.trimIndent()
        ).contains("true")

        delay(4000)
        return success
    }

    suspend fun openFreeCase(webView: WebView): String {
        webView.loadUrl("https://kick.com/")
        delay(5500)

        webView.evaluate(
            """
            (() => {
                const button = [...document.querySelectorAll('button,a')]
                    .find(el => /skip|later|atla/i.test(el.innerText));
                if (button) button.click();
                return true;
            })()
            """.trimIndent()
        )
        delay(1500)

        val clicked = webView.evaluate(
            """
            (() => {
                const target = [...document.querySelectorAll('button,[role=button]')]
                    .find(el => /reward|case|kutu|sunset/i.test(
                        (el.getAttribute('aria-label') || '') + el.innerText + (el.dataset.testid || '')
                    ));
                if (target) { target.click(); return true; }
                return false;
            })()
            """.trimIndent()
        ).contains("true")

        if (!clicked) return "nobox"

        delay(3000)

        webView.evaluate(
            """
            (() => {
                const button = [...document.querySelectorAll('button')]
                    .find(el => /^open|kutuyu ac|^ac$/i.test(el.innerText.trim()));
                if (button) button.click();
                return true;
            })()
            """.trimIndent()
        )
        delay(9000)

        val pageText = webView.evaluate("document.body.innerText.toLowerCase()")
        val winKeywords = listOf(
            "gta vi", "gta 6", "you won", "winner", "congratulations",
            "ultimate edition", "select platform", "xbox", "ps5"
        )
        val score = winKeywords.count { pageText.contains(it) }
        return if (score >= 2) "WIN" else "loss:$score"
    }
}
