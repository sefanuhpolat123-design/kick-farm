package ai.venice.kickfarm

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var logView: TextView
    private lateinit var scrollView: ScrollView
    private var webView: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        Config.init(this)
        Logx.init(this)
        Db.init(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 48, 24, 24)
        }

        root.addView(createField("Gmail adresi", Config.baseEmail) { Config.baseEmail = it })
        root.addView(createField("Gmail uygulama şifresi", Config.appPassword) { Config.appPassword = it })
        root.addView(createField("Telegram bot token (opsiyonel)", Config.telegramToken) { Config.telegramToken = it })
        root.addView(createField("Telegram chat id", Config.telegramChatId) { Config.telegramChatId = it })

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        buttonRow.addView(Button(this).apply {
            text = "BAŞLAT"
            setOnClickListener { startFarm() }
        })
        buttonRow.addView(Button(this).apply {
            text = "DUR"
            setOnClickListener { FarmEngine.stop() }
        })
        buttonRow.addView(Button(this).apply {
            text = "İZİNLER"
            setOnClickListener { requestPermissions() }
        })
        root.addView(buttonRow)

        scrollView = ScrollView(this)
        logView = TextView(this).apply { textSize = 10f }
        scrollView.addView(logView)
        root.addView(scrollView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 280
        ))

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.userAgentString =
                "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            WebView.setWebContentsDebuggingEnabled(true)
        }
        root.addView(
            webView,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)

        Logx.sink = { line ->
            runOnUiThread {
                logView.append("$line\n")
                scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }
    }

    private fun createField(
        hint: String,
        initialValue: String,
        onChange: (String) -> Unit
    ): EditText {
        return EditText(this).apply {
            this.hint = hint
            setText(initialValue)
            textSize = 12f
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = onChange(s?.toString().orEmpty())
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            })
        }
    }

    private fun startFarm() {
        requestPermissions()
        if (Config.appPassword.isBlank()) {
            Logx.w("Gmail uygulama şifresi boş!")
            return
        }
        startForegroundService(Intent(this, FarmService::class.java))
        webView?.let { FarmEngine.start(this, it) }
    }

    private fun requestPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }

        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()

        if (!enabledServices.contains(packageName)) {
            Toast.makeText(this, "Erişilebilirlik servisini aç", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        runCatching {
            startActivity(
                Intent(
                    Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                    Uri.parse("package:$packageName")
                )
            )
        }
    }
}
